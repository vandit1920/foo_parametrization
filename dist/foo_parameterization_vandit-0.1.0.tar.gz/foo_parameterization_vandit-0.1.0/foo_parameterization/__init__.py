"""
Foo Parameterization Package
----------------------------

This package provides functionality to calculate the Foo et al. parameterization for a sphere.
"""